// ═══════════════════════════════════════════════════════
//  RoadmapX — Admin dashboard endpoints
//
//  User schema additions:
//    isAdmin   : Boolean (default false)
//    disabled  : Boolean (default false)
//
//  How to make someone an admin (one-time, from the Mongo shell):
//    db.users.updateOne({username:"you"}, {$set:{isAdmin:true}})
//
//  Reuses requireAuth from earlier snippets.
//  Reuses the connect-mongo `sessions` collection from sessions snippet
//  to force-revoke disabled users' sessions.
// ═══════════════════════════════════════════════════════

const mongoose = require("mongoose");

// Middleware — admin only.
async function requireAdmin(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ success: false, message: "Not signed in." });
  }
  try {
    const u = await User.findOne({ username: req.session.user });
    if (!u || !u.isAdmin) {
      return res.status(403).json({ success: false, message: "Admins only." });
    }
    req.adminUser = u;
    next();
  } catch (err) {
    res.status(500).json({ success: false, message: "Auth check failed." });
  }
}

// Block disabled users from doing anything authenticated.
// Add this to your existing /login (after fetching user, before password check):
//   if (user.disabled) return res.json({ success:false, message:"Account disabled." });
// And as a global gate for protected routes you can also do:
//
//   app.use(async (req, res, next) => {
//     if (req.session?.user) {
//       const u = await User.findOne({ username: req.session.user }).select("disabled");
//       if (u?.disabled) {
//         req.session.destroy(() => res.clearCookie("rx_sid"));
//         return res.status(403).json({ success:false, message:"Account disabled." });
//       }
//     }
//     next();
//   });

// 1) GET /admin/me — quick check used by the dashboard before rendering.
app.get("/admin/me", requireAdmin, (req, res) => {
  res.json({ success: true, username: req.adminUser.username });
});

// 2) GET /admin/users?q=&page=&limit=
app.get("/admin/users", requireAdmin, async (req, res) => {
  try {
    const q     = (req.query.q || "").trim();
    const page  = Math.max(1, parseInt(req.query.page  || "1",  10));
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit || "25", 10)));

    const filter = q
      ? { $or: [
          { username: { $regex: q, $options: "i" } },
          { email:    { $regex: q, $options: "i" } },
        ] }
      : {};

    const [total, rows] = await Promise.all([
      User.countDocuments(filter),
      User.find(filter)
          .select("username email emailVerified twoFactorEnabled isAdmin disabled createdAt")
          .sort({ createdAt: -1 })
          .skip((page - 1) * limit)
          .limit(limit)
          .lean(),
    ]);

    res.json({
      success: true,
      total,
      page,
      limit,
      users: rows.map((u) => ({
        username:         u.username,
        email:            u.email || "",
        emailVerified:    !!u.emailVerified,
        twoFactorEnabled: !!u.twoFactorEnabled,
        isAdmin:          !!u.isAdmin,
        disabled:         !!u.disabled,
        createdAt:        u.createdAt || null,
      })),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not load users." });
  }
});

// 3) POST /admin/users/:username/disable    body: { disabled: bool }
app.post("/admin/users/:username/disable", requireAdmin, async (req, res) => {
  const target = req.params.username;
  const { disabled } = req.body || {};
  if (target === req.adminUser.username) {
    return res.json({ success: false, message: "You can't disable your own account." });
  }
  try {
    const user = await User.findOne({ username: target });
    if (!user) return res.json({ success: false, message: "User not found." });
    user.disabled = !!disabled;
    await user.save();

    // If disabling, revoke all of that user's active sessions.
    if (disabled) {
      const coll = mongoose.connection.collection("sessions");
      const all  = await coll.find({}).toArray();
      const ids  = [];
      for (const row of all) {
        try {
          const parsed = JSON.parse(row.session);
          if (parsed.user === target) ids.push(row._id);
        } catch (_) {}
      }
      if (ids.length) await coll.deleteMany({ _id: { $in: ids } });
    }
    res.json({ success: true, disabled: user.disabled });
  } catch (err) {
    res.status(500).json({ success: false, message: "Update failed." });
  }
});

// 4) POST /admin/users/:username/resend-verify — manually trigger a verify email.
app.post("/admin/users/:username/resend-verify", requireAdmin, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.params.username });
    if (!user) return res.json({ success: false, message: "User not found." });
    if (user.emailVerified) {
      return res.json({ success: false, message: "User is already verified." });
    }
    if (typeof sendVerificationEmail !== "function") {
      return res.json({ success: false, message: "Verification mailer not configured." });
    }
    await sendVerificationEmail(user);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not send email." });
  }
});

// 5) GET /admin/stats — small summary for the top of the dashboard.
app.get("/admin/stats", requireAdmin, async (req, res) => {
  try {
    const [total, verified, admins, disabled, twoFa] = await Promise.all([
      User.countDocuments({}),
      User.countDocuments({ emailVerified: true }),
      User.countDocuments({ isAdmin: true }),
      User.countDocuments({ disabled: true }),
      User.countDocuments({ twoFactorEnabled: true }),
    ]);
    res.json({ success: true, total, verified, admins, disabled, twoFa });
  } catch (err) {
    res.status(500).json({ success: false, message: "Stats failed." });
  }
});
