// ═══════════════════════════════════════════════════════
//  RoadmapX — Google Sign-In bootstrap
//  Renders the official Google button into #g-btn-login and
//  #g-btn-signup, then sends the ID token to the backend.
// ═══════════════════════════════════════════════════════
const G_API      = "http://127.0.0.1:3000";   // must match login_script.js
const G_HOME     = "index.html";

(async function init() {
  // 1) Get the public client ID from the backend (no hard-coding).
  let clientId = "";
  try {
    const r = await fetch(`${G_API}/auth/google/client-id`);
    const j = await r.json();
    clientId = j.clientId || "";
  } catch (_) { /* server down → button just won't render */ }

  if (!clientId) {
    console.warn("[Google Sign-In] No client ID configured on backend.");
    return;
  }

  // 2) Wait until the GSI library is loaded.
  const ready = () => window.google && window.google.accounts && window.google.accounts.id;
  while (!ready()) await new Promise((r) => setTimeout(r, 50));

  google.accounts.id.initialize({
    client_id: clientId,
    callback:  handleGoogleResponse,
    ux_mode:   "popup",
    auto_select: false,
  });

  const opts = {
    type: "standard",
    theme: "filled_black",
    size: "large",
    text: "continue_with",
    shape: "pill",
    logo_alignment: "left",
    width: 280,
  };
  const loginSlot  = document.getElementById("g-btn-login");
  const signupSlot = document.getElementById("g-btn-signup");
  if (loginSlot)  google.accounts.id.renderButton(loginSlot,  opts);
  if (signupSlot) google.accounts.id.renderButton(signupSlot, opts);
})();

async function handleGoogleResponse(response) {
  if (!response || !response.credential) return;

  // Respect the "Remember me" toggle from the login panel if present.
  const remember = !!document.getElementById("remember-me")?.checked;

  const msgEl = document.getElementById("login-msg");
  if (msgEl) {
    msgEl.classList.remove("error");
    msgEl.classList.add("success", "show");
    const t = msgEl.querySelector(".msg-text");
    if (t) t.textContent = "Signing you in with Google…";
  }

  try {
    const res = await fetch(`${G_API}/auth/google`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ credential: response.credential, remember }),
    });
    let data = {};
    try { data = await res.json(); } catch (_) {}

    if (data.success) {
      window.location.href = G_HOME;
    } else {
      showGoogleError(data.message || "Google sign-in failed.");
    }
  } catch (err) {
    showGoogleError("Cannot reach server. Is the backend running?");
  }
}

function showGoogleError(text) {
  const msgEl = document.getElementById("login-msg");
  if (!msgEl) { alert(text); return; }
  msgEl.classList.remove("success");
  msgEl.classList.add("error", "show");
  const t = msgEl.querySelector(".msg-text");
  if (t) t.textContent = text;
}
