// ═══════════════════════════════════════════════════════
//  RoadmapX — Sessions & Devices management
//
//  Builds on backend_remember_snippet.js (express-session +
//  connect-mongo). On every login we tag req.session with
//  device metadata so users can later see and revoke them.
//
//  No new npm packages required.
// ═══════════════════════════════════════════════════════

const mongoose = require("mongoose");

// 1) Middleware — call this AFTER req.session.user is set
//    (i.e. inside /login and /auth/google success branches,
//     right before res.json({ success: true })).
//
//    Usage in /login:
//      req.session.user = user.username;
//      tagSession(req);
function tagSession(req) {
  const ua = req.headers["user-agent"] || "Unknown device";
  req.session.meta = {
    ua,
    ip:        req.ip,
    createdAt: new Date().toISOString(),
    device:    parseDevice(ua),
  };
}

function parseDevice(ua) {
  const u = ua.toLowerCase();
  let os = "Unknown OS";
  if (u.includes("windows"))      os = "Windows";
  else if (u.includes("mac os"))  os = "macOS";
  else if (u.includes("iphone"))  os = "iOS";
  else if (u.includes("ipad"))    os = "iPadOS";
  else if (u.includes("android")) os = "Android";
  else if (u.includes("linux"))   os = "Linux";

  let browser = "Browser";
  if (u.includes("edg/"))             browser = "Edge";
  else if (u.includes("chrome/"))     browser = "Chrome";
  else if (u.includes("firefox/"))    browser = "Firefox";
  else if (u.includes("safari/"))     browser = "Safari";

  return `${browser} on ${os}`;
}

// 2) Helper to require an authenticated user.
function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ success: false, message: "Not signed in." });
  }
  next();
}

// 3) GET /sessions  — list all active sessions for the current user
app.get("/sessions", requireAuth, async (req, res) => {
  try {
    const coll = mongoose.connection.collection("sessions"); // connect-mongo default
    const all  = await coll.find({}).toArray();

    const username = req.session.user;
    const out = [];

    for (const row of all) {
      let parsed;
      try { parsed = JSON.parse(row.session); } catch (_) { continue; }
      if (!parsed || parsed.user !== username) continue;

      out.push({
        id:        row._id,
        device:    parsed.meta?.device    || "Unknown device",
        ua:        parsed.meta?.ua        || "",
        ip:        parsed.meta?.ip        || "",
        createdAt: parsed.meta?.createdAt || null,
        expiresAt: row.expires || null,
        current:   row._id === req.sessionID,
      });
    }

    out.sort((a, b) => (a.current ? -1 : b.current ? 1 : 0));
    res.json({ success: true, sessions: out });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not load sessions." });
  }
});

// 4) DELETE /sessions/:id  — revoke a specific session
app.delete("/sessions/:id", requireAuth, async (req, res) => {
  try {
    const coll = mongoose.connection.collection("sessions");
    const row  = await coll.findOne({ _id: req.params.id });
    if (!row) return res.json({ success: false, message: "Session not found." });

    let parsed;
    try { parsed = JSON.parse(row.session); } catch (_) {}
    if (!parsed || parsed.user !== req.session.user) {
      return res.status(403).json({ success: false, message: "Not allowed." });
    }

    await coll.deleteOne({ _id: req.params.id });

    // If the user revoked their own current session, kill the cookie too.
    if (req.params.id === req.sessionID) {
      req.session.destroy(() => {
        res.clearCookie("rx_sid");
        res.json({ success: true, signedOut: true });
      });
      return;
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not revoke session." });
  }
});

// 5) POST /sessions/revoke-others  — sign out everywhere except here
app.post("/sessions/revoke-others", requireAuth, async (req, res) => {
  try {
    const coll = mongoose.connection.collection("sessions");
    const all  = await coll.find({}).toArray();
    const username   = req.session.user;
    const currentId  = req.sessionID;
    const toDelete   = [];

    for (const row of all) {
      if (row._id === currentId) continue;
      let parsed;
      try { parsed = JSON.parse(row.session); } catch (_) { continue; }
      if (parsed && parsed.user === username) toDelete.push(row._id);
    }

    if (toDelete.length) {
      await coll.deleteMany({ _id: { $in: toDelete } });
    }
    res.json({ success: true, revoked: toDelete.length });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not revoke sessions." });
  }
});
