// ═══════════════════════════════════════════════════════
//  RoadmapX — Password Reset (forgot / reset) backend
//  Add to your Express app next to /login, /register, /me.
//
//  Install once:
//    npm install nodemailer crypto
//
//  Add to .env:
//    SMTP_HOST=smtp.example.com
//    SMTP_PORT=587
//    SMTP_USER=postmaster@example.com
//    SMTP_PASS=...
//    MAIL_FROM="RoadmapX <no-reply@roadmapx.app>"
//    APP_URL=http://127.0.0.1:5500   # your frontend origin
//
//  User schema must have: { username, email, passwordHash,
//                           resetTokenHash, resetTokenExpires }
// ═══════════════════════════════════════════════════════

const crypto     = require("crypto");
const bcrypt     = require("bcrypt");
const nodemailer = require("nodemailer");

const TOKEN_TTL_MS = 1000 * 60 * 30; // 30 minutes

const mailer = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

function hashToken(raw) {
  return crypto.createHash("sha256").update(raw).digest("hex");
}

// 1) POST /forgot-password  body: { email }
//    Always responds success — never reveal whether the email exists.
app.post("/forgot-password", async (req, res) => {
  const { email } = req.body || {};
  if (!email) {
    return res.json({ success: false, message: "Email is required." });
  }

  try {
    const user = await User.findOne({ email: String(email).toLowerCase() });

    if (user) {
      const rawToken = crypto.randomBytes(32).toString("hex");
      user.resetTokenHash    = hashToken(rawToken);
      user.resetTokenExpires = new Date(Date.now() + TOKEN_TTL_MS);
      await user.save();

      const link = `${process.env.APP_URL}/reset-password.html` +
                   `?token=${rawToken}&u=${encodeURIComponent(user.username)}`;

      await mailer.sendMail({
        from: process.env.MAIL_FROM,
        to:   user.email,
        subject: "Reset your RoadmapX password",
        text:
`Hi ${user.username},

We received a request to reset your RoadmapX password.
Click the link below within 30 minutes to choose a new password:

${link}

If you didn't request this, you can ignore this email.`,
      });
    }

    return res.json({
      success: true,
      message: "If that email is registered, a reset link has been sent.",
    });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Could not send reset email." });
  }
});

// 2) POST /reset-password  body: { token, username, password }
app.post("/reset-password", async (req, res) => {
  const { token, username, password } = req.body || {};
  if (!token || !username || !password) {
    return res.json({ success: false, message: "Missing fields." });
  }
  if (password.length < 6) {
    return res.json({
      success: false,
      message: "Password must be at least 6 characters.",
    });
  }

  try {
    const user = await User.findOne({ username });
    if (!user || !user.resetTokenHash || !user.resetTokenExpires) {
      return res.json({ success: false, message: "Invalid or expired link." });
    }
    if (user.resetTokenExpires.getTime() < Date.now()) {
      return res.json({ success: false, message: "This link has expired." });
    }
    if (user.resetTokenHash !== hashToken(token)) {
      return res.json({ success: false, message: "Invalid or expired link." });
    }

    user.passwordHash       = await bcrypt.hash(password, 10);
    user.resetTokenHash     = undefined;
    user.resetTokenExpires  = undefined;
    await user.save();

    return res.json({ success: true, message: "Password updated. You can log in now." });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Could not reset password." });
  }
});
