// ═══════════════════════════════════════════════════════
//  RoadmapX — Rate limiting + account lockout
//
//  npm install express-rate-limit
//
//  User schema additions:
//    failedLoginCount   : { type: Number, default: 0 }
//    lockUntil          : { type: Date }
//
//  Two layers:
//   1) IP rate limit (express-rate-limit) — blocks bursts from one IP
//      across /login, /register, /forgot-password, /reset-password,
//      /2fa/verify-login.
//   2) Per-account lockout — after 5 failed logins in 15 min,
//      the *account* is locked for 15 min regardless of IP.
// ═══════════════════════════════════════════════════════

const rateLimit = require("express-rate-limit");

// ─── 1) IP-based limiters ─────────────────────────────────
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,                          // 20 login attempts per IP / 15 min
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many attempts. Try again in 15 minutes." },
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,                          // 10 signups per IP / hour
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many signup attempts. Try again later." },
});

const passwordResetLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many reset requests. Try again later." },
});

const twoFaLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many 2FA attempts. Try again later." },
});

// Apply to your routes (BEFORE the route handler):
//   app.post("/login",                   loginLimiter,         async (req,res)=>{...});
//   app.post("/register",                signupLimiter,        async (req,res)=>{...});
//   app.post("/forgot-password",         passwordResetLimiter, async (req,res)=>{...});
//   app.post("/reset-password",          passwordResetLimiter, async (req,res)=>{...});
//   app.post("/2fa/verify-login",        twoFaLimiter,         async (req,res)=>{...});

// ─── 2) Per-account lockout helpers ───────────────────────
const MAX_FAILS    = 5;
const LOCK_MS      = 15 * 60 * 1000;   // lockout duration
const FAIL_WINDOW  = 15 * 60 * 1000;   // failures older than this don't count

// Call BEFORE checking the password.
// Returns { locked: true, minutes } if the account is currently locked.
async function checkLock(user) {
  if (user.lockUntil && user.lockUntil.getTime() > Date.now()) {
    const minutes = Math.ceil((user.lockUntil.getTime() - Date.now()) / 60000);
    return { locked: true, minutes };
  }
  return { locked: false };
}

// Call when the password (or 2FA code) is wrong.
async function registerFailedLogin(user) {
  // Reset stale counter
  if (user.lockUntil && user.lockUntil.getTime() < Date.now() - FAIL_WINDOW) {
    user.failedLoginCount = 0;
  }
  user.failedLoginCount = (user.failedLoginCount || 0) + 1;

  if (user.failedLoginCount >= MAX_FAILS) {
    user.lockUntil        = new Date(Date.now() + LOCK_MS);
    user.failedLoginCount = 0;
  }
  await user.save();
  return user.lockUntil && user.lockUntil.getTime() > Date.now();
}

// Call after a successful login to clear counters.
async function clearFailedLogins(user) {
  if (user.failedLoginCount || user.lockUntil) {
    user.failedLoginCount = 0;
    user.lockUntil        = undefined;
    await user.save();
  }
}

// ─── How to wire into your existing /login ────────────────
//
//   app.post("/login", loginLimiter, async (req, res) => {
//     const { username, password, remember } = req.body || {};
//     const user = await User.findOne({ username });
//     if (!user) return res.json({ success:false, message:"Invalid username or password." });
//
//     const lock = await checkLock(user);
//     if (lock.locked) {
//       return res.json({
//         success:false, code:"LOCKED",
//         message:`Account locked. Try again in ${lock.minutes} minute(s).`,
//       });
//     }
//
//     if (!(await bcrypt.compare(password, user.passwordHash))) {
//       const nowLocked = await registerFailedLogin(user);
//       return res.json({
//         success:false,
//         message: nowLocked
//           ? "Too many failed attempts. Account locked for 15 minutes."
//           : "Invalid username or password.",
//       });
//     }
//
//     await clearFailedLogins(user);
//     // ... continue with your existing checks (disabled, emailVerified, 2FA) ...
//   });
//
// And in /2fa/verify-login, call registerFailedLogin(user) on a wrong code so
// attackers can't bypass lockout by guessing 2FA codes after stealing a password.

module.exports = {
  loginLimiter, signupLimiter, passwordResetLimiter, twoFaLimiter,
  checkLock, registerFailedLogin, clearFailedLogins,
};
