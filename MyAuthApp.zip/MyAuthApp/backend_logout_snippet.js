// ═══════════════════════════════════════════════════════
//  RoadmapX — Backend snippets to add to your Express app
//  (Node.js + MongoDB). Drop these into the file where your
//  /login and /register routes already live.
// ═══════════════════════════════════════════════════════

// 1) /logout  — clears server-side session if you use one.
//    Safe to call even when there is no session.
app.post("/logout", (req, res) => {
  try {
    if (req.session) {
      req.session.destroy(() => {
        res.clearCookie("connect.sid");
        return res.json({ success: true, message: "Logged out." });
      });
      return; // destroy() responds asynchronously
    }
    return res.json({ success: true, message: "Logged out." });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Logout failed." });
  }
});

// 2) /me  — optional. Lets the frontend verify a session is
//    still valid (useful if you later move from sessionStorage
//    to real cookie sessions).
app.get("/me", (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ success: true, username: req.session.user });
  }
  return res.status(401).json({ success: false, message: "Not logged in." });
});
