// ═══════════════════════════════════════════════════════
//  RoadmapX — Email Verification on Signup
//  Add to your Express app. Replaces your existing /register
//  and /login bodies (or merge if you already customised them).
//
//  User schema additions required:
//    emailVerified           : Boolean  (default false)
//    verifyTokenHash         : String
//    verifyTokenExpires      : Date
//
//  Reuses the mailer + hashToken() + crypto from
//  backend_password_reset_snippet.js. If that file isn't
//  loaded, copy those helpers in here too.
// ═══════════════════════════════════════════════════════

const VERIFY_TTL_MS = 1000 * 60 * 60 * 24; // 24 hours

async function sendVerificationEmail(user) {
  const rawToken = crypto.randomBytes(32).toString("hex");
  user.verifyTokenHash    = hashToken(rawToken);
  user.verifyTokenExpires = new Date(Date.now() + VERIFY_TTL_MS);
  await user.save();

  const link = `${process.env.APP_URL}/verify-email.html` +
               `?token=${rawToken}&u=${encodeURIComponent(user.username)}`;

  await mailer.sendMail({
    from: process.env.MAIL_FROM,
    to:   user.email,
    subject: "Confirm your RoadmapX email",
    text:
`Hi ${user.username},

Welcome to RoadmapX! Please confirm your email by clicking
the link below within 24 hours:

${link}

If you didn't sign up, you can ignore this message.`,
  });
}

// 1) /register — create unverified account + send verification email.
//    body: { username, email, password }
app.post("/register", async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) {
    return res.json({ success: false, message: "All fields are required." });
  }
  if (password.length < 6) {
    return res.json({ success: false, message: "Password must be at least 6 characters." });
  }

  try {
    const normEmail = String(email).toLowerCase();
    const exists = await User.findOne({ $or: [{ username }, { email: normEmail }] });
    if (exists) {
      return res.json({ success: false, message: "Username or email already in use." });
    }

    const user = new User({
      username,
      email: normEmail,
      passwordHash: await bcrypt.hash(password, 10),
      emailVerified: false,
    });
    await user.save();
    await sendVerificationEmail(user);

    return res.json({
      success: true,
      message: "Account created. Check your inbox to verify your email.",
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Could not create account." });
  }
});

// 2) /login — refuse unverified accounts.
//    Wrap this around your existing /login logic.
app.post("/login", async (req, res) => {
  const { username, password, remember } = req.body || {};
  if (!username || !password) {
    return res.json({ success: false, message: "Missing credentials." });
  }

  const user = await User.findOne({ username });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.json({ success: false, message: "Invalid username or password." });
  }

  if (!user.emailVerified) {
    return res.json({
      success: false,
      code: "EMAIL_NOT_VERIFIED",
      message: "Please verify your email before logging in.",
    });
  }

  req.session.user = user.username;
  if (remember) {
    req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30; // 30 days
  } else {
    req.session.cookie.expires = false;
  }
  return res.json({ success: true, username: user.username });
});

// 3) /verify-email  body: { token, username }
app.post("/verify-email", async (req, res) => {
  const { token, username } = req.body || {};
  if (!token || !username) {
    return res.json({ success: false, message: "Invalid verification link." });
  }
  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.json({ success: false, message: "Invalid verification link." });
    }
    if (user.emailVerified) {
      return res.json({ success: true, message: "Email already verified." });
    }
    if (
      !user.verifyTokenHash ||
      !user.verifyTokenExpires ||
      user.verifyTokenExpires.getTime() < Date.now() ||
      user.verifyTokenHash !== hashToken(token)
    ) {
      return res.json({
        success: false,
        code: "EXPIRED",
        message: "This link is invalid or has expired.",
      });
    }

    user.emailVerified      = true;
    user.verifyTokenHash    = undefined;
    user.verifyTokenExpires = undefined;
    await user.save();

    return res.json({ success: true, message: "Email verified! You can log in now." });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Verification failed." });
  }
});

// 4) /resend-verification  body: { email }
//    Always responds success — never reveals if the email exists.
app.post("/resend-verification", async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.json({ success: false, message: "Email is required." });

  try {
    const user = await User.findOne({ email: String(email).toLowerCase() });
    if (user && !user.emailVerified) {
      await sendVerificationEmail(user);
    }
    return res.json({
      success: true,
      message: "If that account needs verification, a new email has been sent.",
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Could not send email." });
  }
});
