// ═══════════════════════════════════════════════════════
//  RoadmapX — Admin dashboard script
// ═══════════════════════════════════════════════════════
const API = "http://127.0.0.1:3000";

const $ = (id) => document.getElementById(id);
const rowsEl = $("rows");
const toastEl = $("toast");

let state = { q: "", page: 1, limit: 25, total: 0 };

function toast(msg, kind) {
  toastEl.textContent = msg;
  toastEl.className   = "toast show" + (kind === "error" ? " error" : "");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toastEl.classList.remove("show"), 2400);
}

function fmtDate(s) {
  if (!s) return "—";
  try { return new Date(s).toLocaleDateString(); } catch (_) { return "—"; }
}

async function gateCheck() {
  try {
    const res = await fetch(`${API}/admin/me`, { credentials: "include" });
    if (res.status === 401) { window.location.href = "login.html"; return false; }
    if (res.status === 403) {
      document.querySelector(".wrap").innerHTML =
        `<div class="empty" style="color:#ff6b8a">Admins only. You don't have access to this page.</div>`;
      return false;
    }
    return true;
  } catch (_) {
    document.querySelector(".wrap").innerHTML =
      `<div class="empty">Cannot reach server.</div>`;
    return false;
  }
}

async function loadStats() {
  try {
    const r = await fetch(`${API}/admin/stats`, { credentials: "include" });
    const d = await r.json();
    if (!d.success) return;
    const cells = document.querySelectorAll("#stats .stat .n");
    cells[0].textContent = d.total;
    cells[1].textContent = d.verified;
    cells[2].textContent = d.twoFa;
    cells[3].textContent = d.admins;
    cells[4].textContent = d.disabled;
  } catch (_) {}
}

async function loadUsers() {
  rowsEl.innerHTML = `<tr><td colspan="5" class="loading">Loading…</td></tr>`;
  try {
    const url = `${API}/admin/users?q=${encodeURIComponent(state.q)}` +
                `&page=${state.page}&limit=${state.limit}`;
    const r = await fetch(url, { credentials: "include" });
    const d = await r.json();
    if (!d.success) {
      rowsEl.innerHTML = `<tr><td colspan="5" class="empty">${d.message || "Failed."}</td></tr>`;
      return;
    }
    state.total = d.total;
    if (!d.users.length) {
      rowsEl.innerHTML = `<tr><td colspan="5" class="empty">No users found.</td></tr>`;
    } else {
      rowsEl.innerHTML = "";
      d.users.forEach((u) => rowsEl.appendChild(rowFor(u)));
    }
    const start = (state.page - 1) * state.limit + 1;
    const end   = Math.min(state.page * state.limit, state.total);
    $("pager-info").textContent =
      state.total ? `${start}–${end} of ${state.total}` : "0";
    $("prev-btn").disabled = state.page <= 1;
    $("next-btn").disabled = state.page * state.limit >= state.total;
  } catch (_) {
    rowsEl.innerHTML = `<tr><td colspan="5" class="empty">Server unreachable.</td></tr>`;
  }
}

function pill(text, cls) {
  const s = document.createElement("span");
  s.className = "pill " + cls;
  s.textContent = text;
  return s;
}

function rowFor(u) {
  const tr = document.createElement("tr");

  const tdUser = document.createElement("td");
  tdUser.style.fontWeight = "600";
  tdUser.textContent = u.username;
  if (u.isAdmin) { tdUser.appendChild(document.createTextNode(" ")); tdUser.appendChild(pill("ADMIN", "adm")); }

  const tdEmail = document.createElement("td");
  tdEmail.style.fontFamily = "'Courier New',monospace";
  tdEmail.style.fontSize = ".8rem";
  tdEmail.style.color = "#5a6480";
  tdEmail.textContent = u.email || "—";

  const tdStatus = document.createElement("td");
  tdStatus.appendChild(pill(u.emailVerified ? "VERIFIED" : "UNVERIFIED", u.emailVerified ? "ok" : "no"));
  tdStatus.appendChild(document.createTextNode(" "));
  tdStatus.appendChild(pill(u.twoFactorEnabled ? "2FA" : "NO 2FA", u.twoFactorEnabled ? "ok" : "no"));
  if (u.disabled) {
    tdStatus.appendChild(document.createTextNode(" "));
    tdStatus.appendChild(pill("DISABLED", "no"));
  }

  const tdDate = document.createElement("td");
  tdDate.style.color = "#5a6480";
  tdDate.style.fontSize = ".78rem";
  tdDate.textContent = fmtDate(u.createdAt);

  const tdActions = document.createElement("td");
  tdActions.style.textAlign = "right";
  tdActions.style.whiteSpace = "nowrap";

  if (!u.emailVerified) {
    const b = document.createElement("button");
    b.className = "btn tiny";
    b.textContent = "Resend verify";
    b.onclick = () => resendVerify(u.username);
    tdActions.appendChild(b);
    tdActions.appendChild(document.createTextNode(" "));
  }

  if (!u.isAdmin) {
    const b = document.createElement("button");
    b.className = "btn tiny " + (u.disabled ? "" : "danger");
    b.textContent = u.disabled ? "Enable" : "Disable";
    b.onclick = () => toggleDisable(u.username, !u.disabled);
    tdActions.appendChild(b);
  }

  tr.append(tdUser, tdEmail, tdStatus, tdDate, tdActions);
  return tr;
}

async function toggleDisable(username, disabled) {
  if (disabled && !confirm(`Disable account "${username}"? They'll be signed out everywhere.`)) return;
  try {
    const r = await fetch(`${API}/admin/users/${encodeURIComponent(username)}/disable`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ disabled }),
    });
    const d = await r.json();
    if (!d.success) { toast(d.message || "Failed.", "error"); return; }
    toast(disabled ? "Account disabled." : "Account enabled.");
    loadUsers(); loadStats();
  } catch (_) { toast("Server unreachable.", "error"); }
}

async function resendVerify(username) {
  try {
    const r = await fetch(`${API}/admin/users/${encodeURIComponent(username)}/resend-verify`, {
      method: "POST", credentials: "include",
    });
    const d = await r.json();
    toast(d.success ? "Verification email sent." : (d.message || "Failed."), d.success ? "" : "error");
  } catch (_) { toast("Server unreachable.", "error"); }
}

$("search-btn").addEventListener("click", () => { state.q = $("q").value.trim(); state.page = 1; loadUsers(); });
$("q").addEventListener("keydown", (e) => { if (e.key === "Enter") $("search-btn").click(); });
$("refresh-btn").addEventListener("click", () => { loadStats(); loadUsers(); });
$("prev-btn").addEventListener("click", () => { if (state.page > 1) { state.page--; loadUsers(); } });
$("next-btn").addEventListener("click", () => { if (state.page * state.limit < state.total) { state.page++; loadUsers(); } });
$("logout-link").addEventListener("click", (e) => { e.preventDefault(); if (window.rxLogout) window.rxLogout(); });

(async () => {
  if (await gateCheck()) { loadStats(); loadUsers(); }
})();
