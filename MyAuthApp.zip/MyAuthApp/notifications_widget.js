// ═══════════════════════════════════════════════════════
//  RoadmapX — Notifications bell widget
//
//  Drop-in: add ONE line to any authenticated page:
//      <script src="notifications_widget.js" defer></script>
//
//  It auto-injects a fixed bell button (top right) with a
//  red unread badge and a slide-out panel. Polls every 60s.
//
//  Customise placement by setting window.RX_BELL_POS = "top-left"
//  before this script loads. Or anchor it inside an element
//  by setting window.RX_BELL_ANCHOR = "#my-nav-spot".
// ═══════════════════════════════════════════════════════
(function () {
  const API = "http://127.0.0.1:3000"; // must match login_script.js

  const STYLE = `
  .rx-bell-btn{
    position:fixed;top:18px;right:18px;z-index:9998;
    width:42px;height:42px;border-radius:50%;border:1px solid rgba(123,47,255,.3);
    background:rgba(10,10,26,.85);color:#c9d1e0;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    backdrop-filter:blur(10px);transition:border-color .15s;
  }
  .rx-bell-btn:hover{border-color:#00f5d4;color:#00f5d4}
  .rx-bell-btn svg{width:20px;height:20px}
  .rx-bell-btn.left{right:auto;left:18px}
  .rx-bell-btn.anchored{position:static}
  .rx-bell-badge{
    position:absolute;top:-4px;right:-4px;background:#ff6b8a;color:#fff;
    border-radius:99px;font-size:.65rem;font-weight:700;
    min-width:18px;height:18px;padding:0 5px;display:none;
    align-items:center;justify-content:center;font-family:'Courier New',monospace;
  }
  .rx-bell-badge.show{display:flex}
  .rx-bell-panel{
    position:fixed;top:70px;right:18px;width:340px;max-height:70vh;z-index:9999;
    background:rgba(10,10,26,.95);border:1px solid rgba(123,47,255,.3);
    border-radius:12px;backdrop-filter:blur(16px);
    box-shadow:0 10px 40px rgba(0,0,0,.5);
    display:none;flex-direction:column;overflow:hidden;
    color:#c9d1e0;font-family:system-ui,-apple-system,'Segoe UI',sans-serif;
  }
  .rx-bell-panel.left{right:auto;left:18px}
  .rx-bell-panel.show{display:flex}
  .rx-bell-head{
    padding:14px 16px;display:flex;justify-content:space-between;align-items:center;
    border-bottom:1px solid rgba(123,47,255,.15);
  }
  .rx-bell-head h3{
    font-size:.95rem;font-weight:600;
    background:linear-gradient(90deg,#00f5d4,#7b2fff);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  }
  .rx-bell-head a{
    color:#5a6480;font-size:.72rem;cursor:pointer;text-decoration:none;
    font-family:'Courier New',monospace;
  }
  .rx-bell-head a:hover{color:#00f5d4}
  .rx-bell-list{overflow-y:auto;flex:1;padding:4px 0}
  .rx-bell-empty{padding:32px 16px;text-align:center;color:#5a6480;font-size:.85rem}
  .rx-bell-item{
    padding:12px 16px;border-bottom:1px solid rgba(123,47,255,.08);
    display:flex;gap:10px;cursor:default;position:relative;
  }
  .rx-bell-item.unread{background:rgba(123,47,255,.06)}
  .rx-bell-item .dot{
    width:8px;height:8px;border-radius:50%;background:#00f5d4;flex-shrink:0;
    margin-top:6px;visibility:hidden;
  }
  .rx-bell-item.unread .dot{visibility:visible}
  .rx-bell-item .body{flex:1;min-width:0}
  .rx-bell-item .t{font-size:.85rem;font-weight:600;margin-bottom:2px}
  .rx-bell-item .b{font-size:.78rem;color:#9ca3b8;line-height:1.4}
  .rx-bell-item .when{font-size:.7rem;color:#5a6480;margin-top:4px;font-family:'Courier New',monospace}
  .rx-bell-item .x{
    background:none;border:none;color:#5a6480;cursor:pointer;font-size:1rem;
    align-self:flex-start;padding:2px 6px;
  }
  .rx-bell-item .x:hover{color:#ff6b8a}
  .rx-bell-item a.link{color:#00f5d4;text-decoration:none;font-size:.75rem;
                       margin-top:4px;display:inline-block}
  .rx-bell-item a.link:hover{text-decoration:underline}
  .rx-bell-item.SECURITY .t::before{content:"🔒 "}
  .rx-bell-item.WARNING  .t::before{content:"⚠ "}
  .rx-bell-item.ADMIN    .t::before{content:"👤 "}
  .rx-bell-item.INFO     .t::before{content:"ℹ "}
  `;

  const BELL_SVG =
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
       <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>
       <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
     </svg>`;

  function fmtAgo(s) {
    const d = new Date(s);
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60)      return "just now";
    if (diff < 3600)    return Math.floor(diff / 60)   + "m ago";
    if (diff < 86400)   return Math.floor(diff / 3600) + "h ago";
    if (diff < 604800)  return Math.floor(diff / 86400) + "d ago";
    return d.toLocaleDateString();
  }

  function inject() {
    const style = document.createElement("style");
    style.textContent = STYLE;
    document.head.appendChild(style);

    const left = window.RX_BELL_POS === "top-left";

    const btn = document.createElement("button");
    btn.className = "rx-bell-btn" + (left ? " left" : "");
    btn.title = "Notifications";
    btn.innerHTML = BELL_SVG + `<span class="rx-bell-badge" id="rx-bell-badge">0</span>`;

    const panel = document.createElement("div");
    panel.className = "rx-bell-panel" + (left ? " left" : "");
    panel.innerHTML = `
      <div class="rx-bell-head">
        <h3>Notifications</h3>
        <a id="rx-bell-mark">Mark all read</a>
      </div>
      <div class="rx-bell-list" id="rx-bell-list">
        <div class="rx-bell-empty">Loading…</div>
      </div>`;

    const anchorSel = window.RX_BELL_ANCHOR;
    const anchor    = anchorSel ? document.querySelector(anchorSel) : null;
    if (anchor) { btn.classList.add("anchored"); anchor.appendChild(btn); }
    else        { document.body.appendChild(btn); }
    document.body.appendChild(panel);

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const showing = panel.classList.toggle("show");
      if (showing) load();
    });
    document.addEventListener("click", (e) => {
      if (!panel.contains(e.target) && !btn.contains(e.target)) {
        panel.classList.remove("show");
      }
    });
    document.getElementById("rx-bell-mark").addEventListener("click", markAll);
  }

  let lastUnread = 0;

  async function poll() {
    try {
      const r = await fetch(`${API}/notifications?limit=1`, { credentials: "include" });
      if (!r.ok) return;
      const d = await r.json();
      if (!d.success) return;
      setBadge(d.unread);
    } catch (_) {}
  }

  async function load() {
    const list = document.getElementById("rx-bell-list");
    list.innerHTML = `<div class="rx-bell-empty">Loading…</div>`;
    try {
      const r = await fetch(`${API}/notifications?limit=20`, { credentials: "include" });
      if (r.status === 401) { list.innerHTML = `<div class="rx-bell-empty">Sign in to see notifications.</div>`; return; }
      const d = await r.json();
      if (!d.success) { list.innerHTML = `<div class="rx-bell-empty">Could not load.</div>`; return; }
      setBadge(d.unread);
      if (!d.notifications.length) {
        list.innerHTML = `<div class="rx-bell-empty">You're all caught up. ✨</div>`;
        return;
      }
      list.innerHTML = "";
      d.notifications.forEach((n) => list.appendChild(renderItem(n)));
    } catch (_) {
      list.innerHTML = `<div class="rx-bell-empty">Server unreachable.</div>`;
    }
  }

  function renderItem(n) {
    const row = document.createElement("div");
    row.className = "rx-bell-item " + (n.type || "INFO") + (n.read ? "" : " unread");

    const dot  = document.createElement("div"); dot.className = "dot";
    const body = document.createElement("div"); body.className = "body";

    const t = document.createElement("div"); t.className = "t"; t.textContent = n.title;
    const b = document.createElement("div"); b.className = "b"; b.textContent = n.body || "";
    const w = document.createElement("div"); w.className = "when"; w.textContent = fmtAgo(n.createdAt);

    body.append(t, b, w);
    if (n.link) {
      const a = document.createElement("a"); a.className = "link"; a.href = n.link;
      a.textContent = "Open →"; body.appendChild(a);
    }

    const x = document.createElement("button"); x.className = "x"; x.textContent = "✕";
    x.title = "Dismiss";
    x.onclick = async () => {
      try { await fetch(`${API}/notifications/${n._id}`, { method: "DELETE", credentials: "include" }); } catch (_) {}
      row.remove();
      if (!n.read) setBadge(Math.max(0, lastUnread - 1));
    };

    row.append(dot, body, x);

    // Mark this single one read on click into the body.
    body.addEventListener("click", async () => {
      if (n.read) return;
      n.read = true;
      row.classList.remove("unread");
      setBadge(Math.max(0, lastUnread - 1));
      try {
        await fetch(`${API}/notifications/read`, {
          method: "POST", credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: n._id }),
        });
      } catch (_) {}
    });

    return row;
  }

  async function markAll() {
    try {
      await fetch(`${API}/notifications/read`, { method: "POST", credentials: "include" });
      setBadge(0);
      load();
    } catch (_) {}
  }

  function setBadge(n) {
    lastUnread = n;
    const el = document.getElementById("rx-bell-badge");
    if (!el) return;
    el.textContent = n > 99 ? "99+" : String(n);
    el.classList.toggle("show", n > 0);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { inject(); poll(); });
  } else {
    inject(); poll();
  }
  setInterval(poll, 60_000);
})();
