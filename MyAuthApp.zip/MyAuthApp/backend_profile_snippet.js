// ═══════════════════════════════════════════════════════
//  RoadmapX — Profile management
//
//  Lets the signed-in user view their profile, change
//  username/email/password, and delete their account.
//
//  Reuses: requireAuth, bcrypt, mailer, sendVerificationEmail,
//          logAudit (if you added the audit log).
// ═══════════════════════════════════════════════════════

const SAFE_USER_FIELDS = "username email emailVerified twoFactorEnabled isAdmin createdAt avatarUrl";

// 1) GET /profile — returns the current user's data
app.get("/profile", requireAuth, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.session.user })
                           .select(SAFE_USER_FIELDS).lean();
    if (!user) return res.status(404).json({ success: false, message: "Not found." });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
});

// 2) POST /profile/username  body: { newUsername, password }
app.post("/profile/username", requireAuth, async (req, res) => {
  const { newUsername, password } = req.body || {};
  if (!newUsername || newUsername.length < 3) {
    return res.json({ success: false, message: "Username must be at least 3 characters." });
  }
  if (!/^[a-zA-Z0-9_]+$/.test(newUsername)) {
    return res.json({ success: false, message: "Letters, numbers, and underscores only." });
  }
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user) return res.status(404).json({ success: false, message: "Not found." });
    if (user.passwordHash && !(await bcrypt.compare(password || "", user.passwordHash))) {
      return res.json({ success: false, message: "Wrong password." });
    }
    if (newUsername === user.username) {
      return res.json({ success: false, message: "That's already your username." });
    }
    if (await User.findOne({ username: newUsername })) {
      return res.json({ success: false, message: "That username is taken." });
    }

    const old = user.username;
    user.username = newUsername;
    await user.save();
    req.session.user = newUsername; // keep session valid

    if (typeof logAudit === "function") {
      logAudit(req, "USERNAME_CHANGED", { username: newUsername, details:{ from: old } });
    }
    res.json({ success: true, username: newUsername });
  } catch (err) {
    res.status(500).json({ success: false, message: "Update failed." });
  }
});

// 3) POST /profile/email  body: { newEmail, password }
//    Sends verification to the NEW address; email is changed only after click.
app.post("/profile/email", requireAuth, async (req, res) => {
  const { newEmail, password } = req.body || {};
  if (!newEmail || !/.+@.+\..+/.test(newEmail)) {
    return res.json({ success: false, message: "Invalid email." });
  }
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user) return res.status(404).json({ success: false, message: "Not found." });
    if (user.passwordHash && !(await bcrypt.compare(password || "", user.passwordHash))) {
      return res.json({ success: false, message: "Wrong password." });
    }
    const norm = newEmail.toLowerCase();
    if (norm === user.email) {
      return res.json({ success: false, message: "That's already your email." });
    }
    if (await User.findOne({ email: norm })) {
      return res.json({ success: false, message: "That email is in use." });
    }

    // Reuse the verify-email mechanism but route the new address through it.
    user.email          = norm;
    user.emailVerified  = false;
    await user.save();
    if (typeof sendVerificationEmail === "function") await sendVerificationEmail(user);

    if (typeof logAudit === "function") {
      logAudit(req, "EMAIL_CHANGE_REQUESTED", { username: user.username, details:{ to: norm } });
    }
    res.json({ success: true, message: "Check your new inbox to verify the change." });
  } catch (err) {
    res.status(500).json({ success: false, message: "Update failed." });
  }
});

// 4) POST /profile/password  body: { currentPassword, newPassword }
app.post("/profile/password", requireAuth, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 6) {
    return res.json({ success: false, message: "New password must be at least 6 characters." });
  }
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user) return res.status(404).json({ success: false, message: "Not found." });

    if (user.passwordHash) {
      if (!(await bcrypt.compare(currentPassword || "", user.passwordHash))) {
        return res.json({ success: false, message: "Current password is wrong." });
      }
    }
    user.passwordHash = await bcrypt.hash(newPassword, 10);
    await user.save();

    if (typeof logAudit === "function") logAudit(req, "PASSWORD_CHANGED", { username: user.username });

    // Optional: notify by email (if you added login alerts mailer)
    if (typeof mailer !== "undefined" && user.email) {
      mailer.sendMail({
        from: process.env.MAIL_FROM,
        to:   user.email,
        subject: "Your RoadmapX password was changed",
        text: `Hi ${user.username},

Your password was just changed. If this wasn't you, reset it immediately
at ${process.env.APP_URL}/forgot-password.html and revoke active sessions
at ${process.env.APP_URL}/sessions.html.`,
      }).catch(() => {});
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Update failed." });
  }
});

// 5) DELETE /profile  body: { password }  — permanent account deletion
app.delete("/profile", requireAuth, async (req, res) => {
  const { password } = req.body || {};
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user) return res.status(404).json({ success: false, message: "Not found." });
    if (user.isAdmin) {
      return res.json({ success: false, message: "Admins must be demoted before deletion." });
    }
    if (user.passwordHash && !(await bcrypt.compare(password || "", user.passwordHash))) {
      return res.json({ success: false, message: "Wrong password." });
    }

    const username = user.username;
    await User.deleteOne({ _id: user._id });

    // Clean up sessions
    try {
      const coll = mongoose.connection.collection("sessions");
      const all  = await coll.find({}).toArray();
      const ids  = [];
      for (const row of all) {
        try { if (JSON.parse(row.session).user === username) ids.push(row._id); } catch (_) {}
      }
      if (ids.length) await coll.deleteMany({ _id: { $in: ids } });
    } catch (_) {}

    if (typeof logAudit === "function") logAudit(req, "ACCOUNT_DELETED", { username });

    req.session.destroy(() => {
      res.clearCookie("rx_sid");
      res.json({ success: true });
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Delete failed." });
  }
});
