// ═══════════════════════════════════════════════════════
//  RoadmapX — In-app Notifications Center
//
//  No new npm packages required.
//
//  Adds a `notifications` collection. Anywhere in your code
//  call notify(username, type, title, body, link) to push
//  a notification. Users see it in the bell widget.
//
//  Reuses requireAuth.
// ═══════════════════════════════════════════════════════

const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({
  username: { type: String, required: true, index: true },
  type:     { type: String, required: true }, // SECURITY | INFO | WARNING | ADMIN
  title:    { type: String, required: true },
  body:     { type: String, default: "" },
  link:     { type: String, default: "" },    // optional in-app URL
  read:     { type: Boolean, default: false, index: true },
  createdAt:{ type: Date, default: Date.now, index: true },
});
const Notification = mongoose.models.Notification ||
                     mongoose.model("Notification", notificationSchema);

// Fire-and-forget; never throws.
async function notify(username, type, title, body = "", link = "") {
  try {
    await Notification.create({ username, type, title, body, link });
  } catch (_) {}
}

// ─── Where to call notify(...) ────────────────────────────
// /reset-password success:
//   notify(user.username, "SECURITY", "Password changed",
//          "Your account password was just changed.", "/sessions.html");
// /profile/password success:
//   notify(user.username, "SECURITY", "Password changed",
//          "You updated your password from the profile page.");
// /2fa/enable:
//   notify(user.username, "SECURITY", "Two-factor enabled",
//          "Great — your account is now protected with 2FA.");
// /2fa/disable:
//   notify(user.username, "WARNING",  "Two-factor disabled",
//          "If this wasn't you, re-enable it immediately.", "/2fa-setup.html");
// recordLogin() new device:
//   notify(user.username, "SECURITY", "New device signed in",
//          `Sign-in from ${device} (${ip}).`, "/sessions.html");
// /admin disable user (target):
//   notify(target, "ADMIN", "Account disabled",
//          "Your RoadmapX account was disabled by an administrator.");

// ─── Endpoints ────────────────────────────────────────────

// GET /notifications?limit=20  — most recent first + unread count
app.get("/notifications", requireAuth, async (req, res) => {
  try {
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit || "20", 10)));
    const [items, unread] = await Promise.all([
      Notification.find({ username: req.session.user })
        .sort({ createdAt: -1 }).limit(limit).lean(),
      Notification.countDocuments({ username: req.session.user, read: false }),
    ]);
    res.json({ success: true, unread, notifications: items });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
});

// POST /notifications/read  body: { id }   (omit id to mark all)
app.post("/notifications/read", requireAuth, async (req, res) => {
  try {
    const filter = { username: req.session.user, read: false };
    if (req.body && req.body.id) filter._id = req.body.id;
    await Notification.updateMany(filter, { $set: { read: true } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
});

// DELETE /notifications/:id
app.delete("/notifications/:id", requireAuth, async (req, res) => {
  try {
    await Notification.deleteOne({
      _id: req.params.id,
      username: req.session.user,
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
});

module.exports = { notify, Notification };
