// ═══════════════════════════════════════════════════════
//  RoadmapX — Login alert emails
//
//  Sends the user an email when their account is signed in
//  from a new device / IP combination. Reuses your nodemailer
//  `mailer` from backend_password_reset_snippet.js.
//
//  User schema additions:
//    knownLogins : [{
//      hash:      String,    // sha256 of `${ip}|${ua}`
//      ip:        String,
//      device:    String,
//      lastSeen:  Date,
//    }]
//    loginAlertsEnabled : { type: Boolean, default: true }
//
//  Reuses: crypto, hashToken (sha256 helper) from password reset snippet,
//          parseDevice() from sessions snippet.
// ═══════════════════════════════════════════════════════

const KNOWN_LOGIN_KEEP   = 20;       // remember up to N devices
const KNOWN_LOGIN_TTL_MS = 1000 * 60 * 60 * 24 * 90; // forget after 90 days

function fingerprint(ip, ua) {
  return hashToken(`${ip || ""}|${ua || ""}`);
}

// Call AFTER a successful login (any path: /login, /auth/google, /2fa/verify-login).
// Pass the user document and the request.
async function recordLogin(req, user) {
  if (!user) return;

  const ip = req.ip || req.headers["x-forwarded-for"] || "";
  const ua = req.headers["user-agent"] || "";
  const fp = fingerprint(ip, ua);
  const device = (typeof parseDevice === "function") ? parseDevice(ua) : "Unknown device";

  user.knownLogins = (user.knownLogins || []).filter(
    (k) => k && k.lastSeen && (Date.now() - new Date(k.lastSeen).getTime()) < KNOWN_LOGIN_TTL_MS
  );

  const existing = user.knownLogins.find((k) => k.hash === fp);
  const isNewDevice = !existing;

  if (existing) {
    existing.lastSeen = new Date();
  } else {
    user.knownLogins.unshift({ hash: fp, ip, device, lastSeen: new Date() });
    user.knownLogins = user.knownLogins.slice(0, KNOWN_LOGIN_KEEP);
  }
  await user.save();

  if (isNewDevice && user.loginAlertsEnabled !== false && user.email) {
    sendLoginAlert(user, { ip, device, ua }).catch(() => {});
  }
  if (typeof logAudit === "function" && isNewDevice) {
    logAudit(req, "NEW_DEVICE_LOGIN", { username: user.username, details: { device, ip } });
  }
}

async function sendLoginAlert(user, info) {
  if (typeof mailer === "undefined") return;
  const when = new Date().toLocaleString();
  await mailer.sendMail({
    from: process.env.MAIL_FROM,
    to:   user.email,
    subject: "New sign-in to your RoadmapX account",
    text:
`Hi ${user.username},

We noticed a sign-in to your account from a device we haven't seen before.

  When:   ${when}
  Device: ${info.device}
  IP:     ${info.ip || "unknown"}

If this was you, you can ignore this message. If not:

  1. Reset your password: ${process.env.APP_URL}/forgot-password.html
  2. Sign out other devices: ${process.env.APP_URL}/sessions.html
  3. Turn on two-factor auth: ${process.env.APP_URL}/2fa-setup.html

— RoadmapX security`,
  });
}

// User-facing toggle endpoints.
app.get("/profile/login-alerts", requireAuth, async (req, res) => {
  const u = await User.findOne({ username: req.session.user }).select("loginAlertsEnabled");
  res.json({ success: true, enabled: u ? u.loginAlertsEnabled !== false : true });
});

app.post("/profile/login-alerts", requireAuth, async (req, res) => {
  const { enabled } = req.body || {};
  const u = await User.findOne({ username: req.session.user });
  if (!u) return res.status(404).json({ success: false });
  u.loginAlertsEnabled = !!enabled;
  await u.save();
  res.json({ success: true, enabled: u.loginAlertsEnabled });
});

// ─── Where to call recordLogin() ──────────────────────────
//
//   /login           — after `req.session.user = user.username; tagSession(req);`
//                       → await recordLogin(req, user);
//   /2fa/verify-login success — same place.
//   /auth/google success      — same place.
//
// recordLogin is fire-and-forget safe; it never throws.

module.exports = { recordLogin, sendLoginAlert };
