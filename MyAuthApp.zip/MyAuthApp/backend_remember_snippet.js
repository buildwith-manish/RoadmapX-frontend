// ═══════════════════════════════════════════════════════
//  RoadmapX — "Remember Me" backend snippets
//  Node.js + Express + MongoDB (express-session + connect-mongo)
//
//  Install once:
//    npm install express-session connect-mongo cors cookie-parser
// ═══════════════════════════════════════════════════════

const session     = require("express-session");
const MongoStore  = require("connect-mongo");
const cors        = require("cors");

// 1) CORS — must allow credentials so the cookie travels.
//    Replace origin with your frontend URL (NOT "*").
app.use(cors({
  origin: "http://127.0.0.1:5500", // your frontend origin
  credentials: true,
}));

// 2) Session middleware — stores sessions in MongoDB.
//    SHORT cookie when remember = false (browser session only).
//    LONG  cookie when remember = true  (30 days).
app.set("trust proxy", 1); // needed if behind a proxy / HTTPS
app.use(session({
  name: "rx_sid",
  secret: process.env.SESSION_SECRET, // long random string in .env
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: process.env.MONGO_URI,
    collectionName: "sessions",
    ttl: 60 * 60 * 24 * 30, // 30 days
  }),
  cookie: {
    httpOnly: true,                       // JS cannot read it (XSS-safe)
    secure:   process.env.NODE_ENV === "production", // HTTPS only in prod
    sameSite: "lax",
    // maxAge is set per-login below (remember vs not)
  },
}));

// ── Helpers ────────────────────────────────────────────
const THIRTY_DAYS = 1000 * 60 * 60 * 24 * 30;

// 3) /login — accepts { username, password, remember }
app.post("/login", async (req, res) => {
  const { username, password, remember } = req.body || {};
  if (!username || !password) {
    return res.json({ success: false, message: "Missing credentials." });
  }

  const user = await User.findOne({ username });
  if (!user) {
    return res.json({ success: false, message: "Invalid username or password." });
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    return res.json({ success: false, message: "Invalid username or password." });
  }

  // Save user in session
  req.session.user = user.username;

  // Set cookie lifetime based on remember flag
  if (remember) {
    req.session.cookie.maxAge = THIRTY_DAYS;
  } else {
    // No maxAge → browser-session cookie (cleared when browser closes)
    req.session.cookie.expires = false;
  }

  return res.json({ success: true, message: "Logged in.", username: user.username });
});

// 4) /me — frontend uses this on page load to check session
app.get("/me", (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ success: true, username: req.session.user });
  }
  return res.status(401).json({ success: false, message: "Not logged in." });
});

// 5) /logout — destroys session + clears cookie
app.post("/logout", (req, res) => {
  if (!req.session) return res.json({ success: true });
  req.session.destroy(() => {
    res.clearCookie("rx_sid");
    res.json({ success: true, message: "Logged out." });
  });
});
