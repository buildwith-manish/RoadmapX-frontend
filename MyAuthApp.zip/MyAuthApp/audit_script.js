// ═══════════════════════════════════════════════════════
//  RoadmapX — Audit Log page script
// ═══════════════════════════════════════════════════════
const API = "http://127.0.0.1:3000";
const $ = (id) => document.getElementById(id);

const rowsEl = $("rows");
let state = { event: "", username: "", since: "", until: "", page: 1, limit: 50, total: 0 };

const EV_KIND = {
  LOGIN_SUCCESS: "ok", REGISTER: "ok", EMAIL_VERIFIED: "ok",
  PASSWORD_RESET: "ok", "2FA_ENABLED": "ok", GOOGLE_LOGIN: "ok",
  LOGIN_FAIL: "bad", "2FA_LOGIN_FAIL": "bad",
  LOGOUT: "gen", SESSION_REVOKED: "warn", PASSWORD_RESET_REQUEST: "warn",
  "2FA_DISABLED": "warn",
  ADMIN_DISABLE_USER: "adm", ADMIN_ENABLE_USER: "adm", ADMIN_RESEND_VERIFY: "adm",
};

function fmtTs(s) {
  if (!s) return "—";
  try {
    const d = new Date(s);
    return d.toLocaleString();
  } catch (_) { return s; }
}

async function gateCheck() {
  try {
    const r = await fetch(`${API}/admin/me`, { credentials: "include" });
    if (r.status === 401) { window.location.href = "login.html"; return false; }
    if (r.status === 403) {
      document.querySelector(".wrap").innerHTML =
        `<div class="empty" style="color:#ff6b8a">Admins only.</div>`;
      return false;
    }
    return true;
  } catch (_) {
    document.querySelector(".wrap").innerHTML = `<div class="empty">Cannot reach server.</div>`;
    return false;
  }
}

async function loadEventFilter() {
  try {
    const r = await fetch(`${API}/admin/audit/events`, { credentials: "include" });
    const d = await r.json();
    if (!d.success) return;
    const sel = $("f-event");
    d.events.forEach((e) => {
      const o = document.createElement("option");
      o.value = e; o.textContent = e;
      sel.appendChild(o);
    });
  } catch (_) {}
}

async function load() {
  rowsEl.innerHTML = `<tr><td colspan="6" class="loading">Loading…</td></tr>`;
  const params = new URLSearchParams();
  if (state.event)    params.set("event",    state.event);
  if (state.username) params.set("username", state.username);
  if (state.since)    params.set("since",    state.since);
  if (state.until)    params.set("until",    state.until);
  params.set("page",  state.page);
  params.set("limit", state.limit);

  try {
    const r = await fetch(`${API}/admin/audit?${params}`, { credentials: "include" });
    const d = await r.json();
    if (!d.success) {
      rowsEl.innerHTML = `<tr><td colspan="6" class="empty">${d.message || "Failed."}</td></tr>`;
      return;
    }
    state.total = d.total;
    if (!d.events.length) {
      rowsEl.innerHTML = `<tr><td colspan="6" class="empty">No events match these filters.</td></tr>`;
    } else {
      rowsEl.innerHTML = "";
      d.events.forEach((ev) => rowsEl.appendChild(rowFor(ev)));
    }
    const start = (state.page - 1) * state.limit + 1;
    const end   = Math.min(state.page * state.limit, state.total);
    $("pager-info").textContent = state.total ? `${start}–${end} of ${state.total}` : "0";
    $("prev-btn").disabled = state.page <= 1;
    $("next-btn").disabled = state.page * state.limit >= state.total;
  } catch (_) {
    rowsEl.innerHTML = `<tr><td colspan="6" class="empty">Server unreachable.</td></tr>`;
  }
}

function rowFor(ev) {
  const tr = document.createElement("tr");

  const tdTs = document.createElement("td");
  tdTs.className = "ts";
  tdTs.textContent = fmtTs(ev.ts);

  const tdEv = document.createElement("td");
  const span = document.createElement("span");
  span.className = "ev " + (EV_KIND[ev.event] || "gen");
  span.textContent = ev.event;
  tdEv.appendChild(span);

  const tdUser = document.createElement("td");
  tdUser.style.fontWeight = "600";
  tdUser.textContent = ev.username || "—";

  const tdActor = document.createElement("td");
  tdActor.style.color = ev.actor && ev.actor !== ev.username ? "#c4b5fd" : "var(--text-dim)";
  tdActor.textContent = ev.actor || "—";

  const tdIp = document.createElement("td");
  tdIp.className = "ip";
  tdIp.textContent = ev.ip || "—";

  const tdDet = document.createElement("td");
  tdDet.className = "det";
  if (ev.details) {
    try { tdDet.textContent = JSON.stringify(ev.details); }
    catch (_) { tdDet.textContent = String(ev.details); }
  } else {
    tdDet.textContent = ev.ua ? ev.ua.slice(0, 60) + (ev.ua.length > 60 ? "…" : "") : "—";
    tdDet.title = ev.ua || "";
  }

  tr.append(tdTs, tdEv, tdUser, tdActor, tdIp, tdDet);
  return tr;
}

$("apply-btn").addEventListener("click", () => {
  state.event    = $("f-event").value;
  state.username = $("f-user").value.trim();
  state.since    = $("f-since").value;
  state.until    = $("f-until").value;
  state.page = 1;
  load();
});
$("clear-btn").addEventListener("click", () => {
  $("f-event").value = ""; $("f-user").value = "";
  $("f-since").value = ""; $("f-until").value = "";
  state = { event:"", username:"", since:"", until:"", page:1, limit:50, total:0 };
  load();
});
$("prev-btn").addEventListener("click", () => { if (state.page > 1) { state.page--; load(); } });
$("next-btn").addEventListener("click", () => { if (state.page * state.limit < state.total) { state.page++; load(); } });
$("logout-link").addEventListener("click", (e) => { e.preventDefault(); if (window.rxLogout) window.rxLogout(); });

(async () => { if (await gateCheck()) { await loadEventFilter(); load(); } })();
