// ═══════════════════════════════════════════════════════
//  RoadmapX — Audit Log
//
//  No new npm packages required.
//
//  Adds a `auditlogs` collection that records important
//  account actions. Admins can view & filter via /admin/audit.
//
//  Events recorded (call logAudit(...) at these points):
//    LOGIN_SUCCESS, LOGIN_FAIL, LOGOUT,
//    REGISTER, EMAIL_VERIFIED, PASSWORD_RESET_REQUEST, PASSWORD_RESET,
//    2FA_ENABLED, 2FA_DISABLED, 2FA_LOGIN_FAIL,
//    GOOGLE_LOGIN, SESSION_REVOKED,
//    ADMIN_DISABLE_USER, ADMIN_ENABLE_USER, ADMIN_RESEND_VERIFY
// ═══════════════════════════════════════════════════════

const mongoose = require("mongoose");

const auditSchema = new mongoose.Schema({
  ts:        { type: Date, default: Date.now, index: true },
  event:     { type: String, required: true, index: true },
  username:  { type: String, index: true },   // subject of the event
  actor:     { type: String },                // who performed it (admin actions)
  ip:        { type: String },
  ua:        { type: String },
  details:   { type: Object },                // freeform extras
});
const AuditLog = mongoose.models.AuditLog || mongoose.model("AuditLog", auditSchema);

// Call from anywhere. Never throws — failures are swallowed so audit
// logging never breaks the user's request.
async function logAudit(req, event, opts = {}) {
  try {
    await AuditLog.create({
      event,
      username: opts.username || (req && req.session && req.session.user) || null,
      actor:    opts.actor    || (req && req.session && req.session.user) || null,
      ip:       (req && (req.ip || req.headers["x-forwarded-for"])) || null,
      ua:       (req && req.headers && req.headers["user-agent"]) || null,
      details:  opts.details  || null,
    });
  } catch (_) { /* swallow */ }
}

// Expose so other snippets can call it.
module.exports = { logAudit, AuditLog };

// ─── Where to call logAudit() in your existing routes ─────
// These are one-line additions; do NOT replace your handlers.
//
//   /login  success:                   logAudit(req, "LOGIN_SUCCESS", { username: user.username });
//   /login  bad password:              logAudit(req, "LOGIN_FAIL",    { username, details:{ reason:"BAD_PASSWORD" } });
//   /login  disabled account:          logAudit(req, "LOGIN_FAIL",    { username, details:{ reason:"DISABLED" } });
//   /logout:                           logAudit(req, "LOGOUT");
//   /register success:                 logAudit(req, "REGISTER",      { username });
//   /verify-email success:             logAudit(req, "EMAIL_VERIFIED",{ username });
//   /forgot-password (any):            logAudit(req, "PASSWORD_RESET_REQUEST", { details:{ email } });
//   /reset-password success:           logAudit(req, "PASSWORD_RESET",{ username });
//   /2fa/enable success:               logAudit(req, "2FA_ENABLED");
//   /2fa/disable success:              logAudit(req, "2FA_DISABLED");
//   /2fa/verify-login fail:            logAudit(req, "2FA_LOGIN_FAIL", { username: pending.username });
//   /auth/google success:              logAudit(req, "GOOGLE_LOGIN",  { username: user.username });
//   /sessions/:id DELETE:              logAudit(req, "SESSION_REVOKED", { details:{ id: req.params.id } });
//   /admin/users/:u/disable enable:    logAudit(req, "ADMIN_ENABLE_USER",  { username: target, actor: req.adminUser.username });
//   /admin/users/:u/disable disable:   logAudit(req, "ADMIN_DISABLE_USER", { username: target, actor: req.adminUser.username });
//   /admin/users/:u/resend-verify:     logAudit(req, "ADMIN_RESEND_VERIFY",{ username: req.params.username, actor: req.adminUser.username });

// ─── Admin endpoints to read the log ──────────────────────
// (Reuses requireAdmin from backend_admin_snippet.js)

// GET /admin/audit?event=&username=&page=&limit=&since=&until=
app.get("/admin/audit", requireAdmin, async (req, res) => {
  try {
    const page  = Math.max(1, parseInt(req.query.page  || "1",  10));
    const limit = Math.min(200, Math.max(1, parseInt(req.query.limit || "50", 10)));
    const filter = {};
    if (req.query.event)    filter.event    = req.query.event;
    if (req.query.username) filter.username = req.query.username;
    if (req.query.since || req.query.until) {
      filter.ts = {};
      if (req.query.since) filter.ts.$gte = new Date(req.query.since);
      if (req.query.until) filter.ts.$lte = new Date(req.query.until);
    }

    const [total, rows] = await Promise.all([
      AuditLog.countDocuments(filter),
      AuditLog.find(filter).sort({ ts: -1 })
        .skip((page - 1) * limit).limit(limit).lean(),
    ]);

    res.json({
      success: true,
      total, page, limit,
      events: rows.map((r) => ({
        ts:       r.ts,
        event:    r.event,
        username: r.username || "",
        actor:    r.actor || "",
        ip:       r.ip || "",
        ua:       r.ua || "",
        details:  r.details || null,
      })),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not load audit log." });
  }
});

// GET /admin/audit/events — distinct event names, for the filter dropdown.
app.get("/admin/audit/events", requireAdmin, async (req, res) => {
  try {
    const events = await AuditLog.distinct("event");
    res.json({ success: true, events: events.sort() });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed." });
  }
});
