// ═══════════════════════════════════════════════════════
//  RoadmapX — Auth Guard (cookie-session edition)
//  Include on EVERY protected page BEFORE your main script:
//    <script src="auth_guard.js"></script>
//    <script src="script.js" defer></script>
// ═══════════════════════════════════════════════════════

(function () {
  const API = "http://127.0.0.1:3000"; // must match login_script.js
  const LOGIN_PAGE = "login.html";

  // Hide page until session is verified — prevents flash of content
  // for unauthenticated users.
  const styleEl = document.createElement("style");
  styleEl.textContent = "html{visibility:hidden!important}";
  document.documentElement.appendChild(styleEl);

  function reveal() {
    styleEl.remove();
  }

  function bounceToLogin() {
    window.location.replace(LOGIN_PAGE);
  }

  // Ask the backend if our cookie is still valid.
  fetch(`${API}/me`, { credentials: "include" })
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      if (!data || !data.success) {
        bounceToLogin();
        return;
      }
      window.RX_USER = data.username;
      reveal();
    })
    .catch(() => {
      // Server unreachable. Fail closed — send to login.
      bounceToLogin();
    });

  // Logout helper for the rest of the app
  window.rxLogout = async function () {
    try {
      await fetch(`${API}/logout`, {
        method: "POST",
        credentials: "include",
      });
    } catch (_) {}
    try {
      sessionStorage.clear();
      ["rx_user", "rx_users", "rx_token", "user", "loggedInUser"].forEach((k) =>
        localStorage.removeItem(k)
      );
    } catch (_) {}
    window.location.replace(LOGIN_PAGE);
  };
})();
