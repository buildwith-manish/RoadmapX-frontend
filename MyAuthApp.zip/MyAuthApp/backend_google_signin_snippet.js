// ═══════════════════════════════════════════════════════
//  RoadmapX — Google Sign-In (Google Identity Services)
//
//  npm install google-auth-library
//
//  Env vars required:
//    GOOGLE_CLIENT_ID  — your OAuth 2.0 Client ID from
//                        https://console.cloud.google.com/apis/credentials
//                        (type: "Web application", add your site origin to
//                         "Authorized JavaScript origins")
//
//  User schema additions (optional but recommended):
//    googleId          : String    (unique, sparse)
//    avatarUrl         : String
//
//  Reuses your existing express-session setup (cookie name `rx_sid`)
//  from backend_remember_snippet.js.
// ═══════════════════════════════════════════════════════

const { OAuth2Client } = require("google-auth-library");
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// POST /auth/google   body: { credential, remember }
//   `credential` is the JWT ID token returned by the Google button.
app.post("/auth/google", async (req, res) => {
  const { credential, remember } = req.body || {};
  if (!credential) {
    return res.json({ success: false, message: "Missing Google credential." });
  }

  let payload;
  try {
    const ticket = await googleClient.verifyIdToken({
      idToken:  credential,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    payload = ticket.getPayload();
  } catch (err) {
    return res.json({ success: false, message: "Invalid Google token." });
  }

  if (!payload || !payload.email || !payload.email_verified) {
    return res.json({
      success: false,
      message: "Google account email is not verified.",
    });
  }

  const googleId = payload.sub;
  const email    = payload.email.toLowerCase();
  const name     = payload.name || payload.given_name || email.split("@")[0];
  const picture  = payload.picture || "";

  try {
    // Match by googleId first, then fall back to email so users who
    // signed up the normal way can link their Google account.
    let user = await User.findOne({ $or: [{ googleId }, { email }] });

    if (!user) {
      // Generate a unique username from the Google name
      let base = name.replace(/[^a-zA-Z0-9_]/g, "").slice(0, 20) || "user";
      let username = base;
      let n = 1;
      while (await User.findOne({ username })) {
        username = `${base}${n++}`;
      }

      user = new User({
        username,
        email,
        googleId,
        avatarUrl:     picture,
        emailVerified: true,         // Google already verified it
        passwordHash:  "",            // no password for Google-only accounts
      });
      await user.save();
    } else if (!user.googleId) {
      // Existing email-based account → link the Google ID
      user.googleId      = googleId;
      user.emailVerified = true;
      if (!user.avatarUrl) user.avatarUrl = picture;
      await user.save();
    }

    req.session.user = user.username;
    if (remember) {
      req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30; // 30 days
    } else {
      req.session.cookie.expires = false;
    }

    return res.json({ success: true, username: user.username });
  } catch (err) {
    return res.status(500).json({ success: false, message: "Sign-in failed." });
  }
});

// GET /auth/google/client-id  — lets the frontend fetch the public client ID
//   so you don't have to hard-code it in HTML.
app.get("/auth/google/client-id", (req, res) => {
  res.json({ clientId: process.env.GOOGLE_CLIENT_ID || "" });
});
