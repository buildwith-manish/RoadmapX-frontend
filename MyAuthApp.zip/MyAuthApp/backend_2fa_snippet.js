// ═══════════════════════════════════════════════════════
//  RoadmapX — Two-Factor Authentication (TOTP)
//
//  npm install speakeasy qrcode
//
//  User schema additions:
//    twoFactorEnabled    : Boolean  (default false)
//    twoFactorSecret     : String   (base32, set during setup)
//    twoFactorBackupHashes: [String] (sha256 of single-use backup codes)
//
//  Flow:
//    1) Logged-in user calls /2fa/setup → gets QR code + secret.
//    2) User scans into Google Authenticator / Authy / 1Password.
//    3) User submits a code to /2fa/enable → 2FA is on, backup codes returned.
//    4) On future /login, if 2FA is enabled, the response is:
//         { success:false, code:"2FA_REQUIRED", challengeId }
//       Frontend collects the code and calls /2fa/verify-login.
//    5) /2fa/disable requires a current TOTP code.
// ═══════════════════════════════════════════════════════

const speakeasy = require("speakeasy");
const QRCode    = require("qrcode");
// Reuses `crypto`, `hashToken`, `requireAuth`, `tagSession` from earlier snippets.

// In-memory pending-login store (keyed by random challengeId).
// For production with multiple servers, move this to Redis or Mongo.
const pendingLogins = new Map(); // challengeId -> { username, remember, expires }
setInterval(() => {
  const now = Date.now();
  for (const [id, p] of pendingLogins) if (p.expires < now) pendingLogins.delete(id);
}, 60_000);

function newBackupCodes(n = 10) {
  const codes = [];
  for (let i = 0; i < n; i++) {
    // Format: XXXX-XXXX (uppercase alphanumeric)
    const raw = crypto.randomBytes(5).toString("hex").toUpperCase();
    codes.push(`${raw.slice(0, 4)}-${raw.slice(4, 8)}`);
  }
  return codes;
}

// 1) /2fa/setup  — generate a secret + QR for the logged-in user
app.post("/2fa/setup", requireAuth, async (req, res) => {
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user) return res.status(404).json({ success: false, message: "User not found." });
    if (user.twoFactorEnabled) {
      return res.json({ success: false, message: "2FA is already enabled." });
    }

    const secret = speakeasy.generateSecret({
      name: `RoadmapX (${user.username})`,
      issuer: "RoadmapX",
      length: 20,
    });

    // Stash provisionally — only marked "enabled" after /2fa/enable succeeds.
    user.twoFactorSecret = secret.base32;
    await user.save();

    const otpauthUrl = secret.otpauth_url;
    const qrDataUrl  = await QRCode.toDataURL(otpauthUrl);

    res.json({
      success: true,
      secret:  secret.base32,
      qrDataUrl,
      otpauthUrl,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Setup failed." });
  }
});

// 2) /2fa/enable  body: { code }
app.post("/2fa/enable", requireAuth, async (req, res) => {
  const { code } = req.body || {};
  if (!code) return res.json({ success: false, message: "Code required." });

  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user || !user.twoFactorSecret) {
      return res.json({ success: false, message: "Run setup first." });
    }
    const ok = speakeasy.totp.verify({
      secret:   user.twoFactorSecret,
      encoding: "base32",
      token:    String(code).replace(/\s/g, ""),
      window:   1,
    });
    if (!ok) return res.json({ success: false, message: "Invalid code. Try again." });

    const backupCodes = newBackupCodes();
    user.twoFactorEnabled       = true;
    user.twoFactorBackupHashes  = backupCodes.map(hashToken);
    await user.save();

    res.json({ success: true, backupCodes });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not enable 2FA." });
  }
});

// 3) /2fa/disable  body: { code }
app.post("/2fa/disable", requireAuth, async (req, res) => {
  const { code } = req.body || {};
  try {
    const user = await User.findOne({ username: req.session.user });
    if (!user || !user.twoFactorEnabled) {
      return res.json({ success: false, message: "2FA is not enabled." });
    }
    const ok = speakeasy.totp.verify({
      secret:   user.twoFactorSecret,
      encoding: "base32",
      token:    String(code || "").replace(/\s/g, ""),
      window:   1,
    });
    if (!ok) return res.json({ success: false, message: "Invalid code." });

    user.twoFactorEnabled      = false;
    user.twoFactorSecret       = undefined;
    user.twoFactorBackupHashes = [];
    await user.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: "Could not disable 2FA." });
  }
});

// 4) /2fa/status  — used by the settings page
app.get("/2fa/status", requireAuth, async (req, res) => {
  const user = await User.findOne({ username: req.session.user });
  res.json({
    success: true,
    enabled: !!(user && user.twoFactorEnabled),
  });
});

// 5) Modify your existing /login: AFTER password check passes,
//    BEFORE setting req.session.user, insert this block:
//
//    if (user.twoFactorEnabled) {
//      const challengeId = crypto.randomBytes(24).toString("hex");
//      pendingLogins.set(challengeId, {
//        username: user.username,
//        remember: !!remember,
//        expires:  Date.now() + 5 * 60 * 1000, // 5 min
//      });
//      return res.json({ success: false, code: "2FA_REQUIRED", challengeId });
//    }
//    req.session.user = user.username;
//    tagSession(req);
//    ...

// 6) /2fa/verify-login  body: { challengeId, code }
app.post("/2fa/verify-login", async (req, res) => {
  const { challengeId, code } = req.body || {};
  if (!challengeId || !code) {
    return res.json({ success: false, message: "Missing fields." });
  }
  const pending = pendingLogins.get(challengeId);
  if (!pending || pending.expires < Date.now()) {
    pendingLogins.delete(challengeId);
    return res.json({ success: false, message: "Login session expired. Sign in again." });
  }

  try {
    const user = await User.findOne({ username: pending.username });
    if (!user || !user.twoFactorEnabled) {
      pendingLogins.delete(challengeId);
      return res.json({ success: false, message: "Invalid request." });
    }

    const cleaned = String(code).replace(/\s/g, "").toUpperCase();
    let ok = false;

    // Try TOTP first (6 digits)
    if (/^\d{6}$/.test(cleaned)) {
      ok = speakeasy.totp.verify({
        secret:   user.twoFactorSecret,
        encoding: "base32",
        token:    cleaned,
        window:   1,
      });
    }

    // Then try a backup code (one-time use)
    if (!ok && /^[A-Z0-9]{4}-?[A-Z0-9]{4}$/.test(cleaned)) {
      const normalized = cleaned.includes("-") ? cleaned : `${cleaned.slice(0,4)}-${cleaned.slice(4)}`;
      const h = hashToken(normalized);
      const idx = (user.twoFactorBackupHashes || []).indexOf(h);
      if (idx !== -1) {
        ok = true;
        user.twoFactorBackupHashes.splice(idx, 1);
        await user.save();
      }
    }

    if (!ok) return res.json({ success: false, message: "Invalid code." });

    pendingLogins.delete(challengeId);
    req.session.user = user.username;
    tagSession(req);
    if (pending.remember) {
      req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30;
    } else {
      req.session.cookie.expires = false;
    }
    res.json({
      success: true,
      username: user.username,
      backupCodesRemaining: (user.twoFactorBackupHashes || []).length,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Verification failed." });
  }
});
